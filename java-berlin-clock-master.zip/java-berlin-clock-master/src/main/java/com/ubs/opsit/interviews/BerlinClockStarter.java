package com.ubs.opsit.interviews;

public class BerlinClockStarter {

	public static void main(String[] args) {
		TimeConverter timeConverter = new TimeConverterImpl();
		System.out.println(timeConverter.convertTime("00:00:00"));
	}

}
