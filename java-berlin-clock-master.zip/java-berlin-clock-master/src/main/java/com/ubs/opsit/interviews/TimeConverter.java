package com.ubs.opsit.interviews;

public interface TimeConverter {

    String convertTime(String aTime);

	String getLamps(int time);

	String getLamps(int time, int unit, String lampColor);
	
	String getLamps(int timeUnitValue, int numericValue,String strRedLamp, String strYellowLamp);
}
