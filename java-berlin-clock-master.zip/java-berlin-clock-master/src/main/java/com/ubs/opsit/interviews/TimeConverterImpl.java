package com.ubs.opsit.interviews;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TimeConverterImpl implements TimeConverter {
	
	@Override
	public String convertTime(String aTime) {
		
		if (!validateTime(aTime)) {
			return TimeConstants.INVALID_TIME;
		}

		int timeUnitDivisibleByFive;
		int timeUnitModulusOfFive;
		int timeUnitValue;

		String[] splitTime = aTime.split(TimeConstants.COLON);

		StringBuilder convertedTime = new StringBuilder();

		convertedTime.append(getLamps(Integer.parseInt(splitTime[2])));

		convertedTime.append(TimeConstants.LINE_SEPARATOR);

		timeUnitValue = Integer.parseInt(splitTime[0]);
		timeUnitDivisibleByFive = timeUnitValue / TimeConstants.MULTIPLE_OF_FIVE;
		timeUnitModulusOfFive = timeUnitValue % TimeConstants.MULTIPLE_OF_FIVE;

		convertedTime.append(getLamps(timeUnitValue, timeUnitDivisibleByFive, TimeConstants.RED_LAMP));
		convertedTime.append(TimeConstants.LINE_SEPARATOR);

		convertedTime.append(getLamps(timeUnitValue, timeUnitModulusOfFive, TimeConstants.RED_LAMP));
		convertedTime.append(TimeConstants.LINE_SEPARATOR);

		timeUnitValue = Integer.parseInt(splitTime[1]);
		timeUnitDivisibleByFive = timeUnitValue / TimeConstants.MULTIPLE_OF_FIVE;
		timeUnitModulusOfFive = timeUnitValue % TimeConstants.MULTIPLE_OF_FIVE;

		convertedTime.append(getLamps(timeUnitValue, timeUnitDivisibleByFive, TimeConstants.RED_LAMP, TimeConstants.YELLOW_LAMP));
		convertedTime.append(TimeConstants.LINE_SEPARATOR);

		convertedTime.append(getLamps(timeUnitValue, timeUnitModulusOfFive, TimeConstants.YELLOW_LAMP));

		return convertedTime.toString();
	}

	private boolean validateTime(String inputTime) {

		try {
			if (inputTime != null && !inputTime.isEmpty()) {
				Pattern timeRegexPattern = Pattern.compile(TimeConstants.TIME_REGEX_PATTERN);
				Matcher timeMatcher = timeRegexPattern.matcher(inputTime);
				if (!timeMatcher.matches()) {
					return false;
				}
			} else {
				return false;
			}
		} catch (Exception e) {
			System.out.println("Exception occured in validation method :-" + e.getMessage());
		}
		return true;
	}

	@Override
	public String getLamps(int time) {
		if (time % 2 == 0)
			return TimeConstants.YELLOW_LAMP;
		else
			return TimeConstants.OFF_LAMP;
	}

	@Override
	public String getLamps(int time, int unit, String lampColor) {
		StringBuilder lamps = new StringBuilder(TimeConstants.ALL_OFF_LAMP);
		for (int i = 0; i < unit; i++) {
			lamps.replace(i, i + 1, lampColor);
		}
		return lamps.toString();
	}

	@Override
	public String getLamps(int timeUnitValue, int numericValue, String strRedLamp, String strYellowLamp) {

		StringBuilder lamps = new StringBuilder(TimeConstants.ELEVEN_OFF_LAMPS);

		for (int i = 0; i < numericValue; i++) {
			if ((i + 1) % 3 == 0) {
				lamps.replace(i, i + 1, strRedLamp);
			} else {
				lamps.replace(i, i + 1, strYellowLamp);
			}
		}
		return lamps.toString();
	}

}
